import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

import engine.Game;

public class Champions extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Marvel main;
	private JLabel one;
	private JLabel two;
	private JButton info;
	private JRadioButton r1;
	private JRadioButton r2;
	private JRadioButton r3;
	private JRadioButton r4;
	private JRadioButton r5;
	private JRadioButton r6;
	private JRadioButton r7;
	private JRadioButton r8;
	private JRadioButton r9;
	private JRadioButton r10;
	private JRadioButton r11;
	private JRadioButton r12;
	private JRadioButton r13;
	private JRadioButton r14;
	private JRadioButton r15;
	private JRadioButton r16;
	private JRadioButton r17;
	private JRadioButton r18;
	private JRadioButton r19;
	private JRadioButton r20;
	private JRadioButton r21;
	private JRadioButton r22;
	private JRadioButton r23;
	private JRadioButton r24;
	private JRadioButton r25;
	private JRadioButton r26;
	private JRadioButton r27;
	private JRadioButton r28;
	private JRadioButton r29;
	private JRadioButton r30;
	private JComboBox<String> c1;
	private JComboBox<String> c2;
	private JButton play;
	
	public Champions(Marvel main) {
		 this.main=main;
		 this.setLayout(null);
		 main.setSize(1200,700);
		 main.setResizable(false);
		 
		 one=new JLabel(main.getPlayerOnesName() + " please select your 3 champions");
		 one.setBounds(20, 10, 500, 20);
		 this.add(one);
		 
		 two= new JLabel(main.getPlayerTwosName() + " please select your 3 champions");
		 two.setBounds(900,10,500,20);
		 this.add(two);
		 
		 info=new JButton("Champion's information");
		 info.setBounds(900, 600, 300, 30);
		 this.add(info);
		 info.addActionListener(this);
		 
		 c1=new JComboBox<String>(AvailableChampionsByNames());
		 c1.setBounds(20,530,300,30);
		 c1.addActionListener(this);
		 this.add(c1);
		
		 c2=new JComboBox<String>(AvailableChampionsByNames());
		 c2.setBounds(900, 530, 300, 30);
		 c2.addActionListener(this);
		 this.add(c2);
		 
		r1= new JRadioButton(Game.getAvailableChampions().get(0).getName());
		r1.setSelected(true);
		r1.setBounds(20, 50,150,50);
		this.add(r1);
		
		r2= new JRadioButton(Game.getAvailableChampions().get(1).getName());
		r2.setSelected(true);
		r2.setBounds(20, 80,95,50);
		this.add(r2);
		
		r3= new JRadioButton(Game.getAvailableChampions().get(2).getName());
		r3.setSelected(true);
		r3.setBounds(20, 110,105,50);
		this.add(r3);
		
		r4= new JRadioButton(Game.getAvailableChampions().get(3).getName());
		r4.setBounds(20, 140,75,50);
		this.add(r4);
		
		r5= new JRadioButton(Game.getAvailableChampions().get(4).getName());
		r5.setBounds(20, 170,110,50);
		this.add(r5);
		
		r6= new JRadioButton(Game.getAvailableChampions().get(5).getName());
		r6.setBounds(20, 200,70,50);
		this.add(r6);
		
		r7= new JRadioButton(Game.getAvailableChampions().get(6).getName());
		r7.setBounds(20, 230,70,50);
		this.add(r7);
		
		r8= new JRadioButton(Game.getAvailableChampions().get(7).getName());
		r8.setBounds(20, 260,100,50);
		this.add(r8);
		
		r9= new JRadioButton(Game.getAvailableChampions().get(8).getName());
		r9.setBounds(20, 290,100,50);
		this.add(r9);
		
		r10= new JRadioButton(Game.getAvailableChampions().get(9).getName());
		r10.setBounds(20, 320,80,50);
		this.add(r10);
		
		r11= new JRadioButton(Game.getAvailableChampions().get(10).getName());
		r11.setBounds(20, 350,120,50);
		this.add(r11);
		
		r12= new JRadioButton(Game.getAvailableChampions().get(11).getName());
		r12.setBounds(20, 380,110,50);
		this.add(r12);
		
		r13= new JRadioButton(Game.getAvailableChampions().get(12).getName());
		r13.setBounds(20, 410,70,50);
		this.add(r13);
		
		r14= new JRadioButton(Game.getAvailableChampions().get(13).getName());
		r14.setBounds(20, 440,80,50);
		this.add(r14);
		
		r15= new JRadioButton(Game.getAvailableChampions().get(14).getName());
		r15.setBounds(20, 470,115,50);
		this.add(r15);
		
		r16= new JRadioButton(Game.getAvailableChampions().get(0).getName());		
		r16.setBounds(900, 50,150,50);
		this.add(r16);
		
		r17= new JRadioButton(Game.getAvailableChampions().get(1).getName());		
		r17.setBounds(900, 80,95,50);
		this.add(r17);
		
		r18= new JRadioButton(Game.getAvailableChampions().get(2).getName());
		r18.setBounds(900, 110,105,50);
		this.add(r18);
		
		r19= new JRadioButton(Game.getAvailableChampions().get(3).getName());
		r19.setSelected(true);
		r19.setBounds(900, 140,75,50);
		this.add(r19);
		
		r20= new JRadioButton(Game.getAvailableChampions().get(4).getName());
		r20.setSelected(true);
		r20.setBounds(900, 170,110,50);
		this.add(r20);
		
		r21= new JRadioButton(Game.getAvailableChampions().get(5).getName());
		r21.setSelected(true);
		r21.setBounds(900, 200,70,50);
		this.add(r21);
		
		r22= new JRadioButton(Game.getAvailableChampions().get(6).getName());
		r22.setBounds(900, 230,70,50);
		this.add(r22);
		
		r23= new JRadioButton(Game.getAvailableChampions().get(7).getName());
		r23.setBounds(900, 260,100,50);
		this.add(r23);
		
		r24= new JRadioButton(Game.getAvailableChampions().get(8).getName());
		r24.setBounds(900, 290,100,50);
		this.add(r24);
		
		r25= new JRadioButton(Game.getAvailableChampions().get(9).getName());
		r25.setBounds(900, 320,80,50);
		this.add(r25);
		
		r26= new JRadioButton(Game.getAvailableChampions().get(10).getName());
		r26.setBounds(900, 350,120,50);
		this.add(r26);
		
		r27= new JRadioButton(Game.getAvailableChampions().get(11).getName());
		r27.setBounds(900, 380,110,50);
		this.add(r27);
		
		r28= new JRadioButton(Game.getAvailableChampions().get(12).getName());
		r28.setBounds(900, 410,70,50);
		this.add(r28);
		
		r29= new JRadioButton(Game.getAvailableChampions().get(13).getName());
		r29.setBounds(900, 440,80,50);
		this.add(r29);
		
		r30= new JRadioButton(Game.getAvailableChampions().get(14).getName());
		r30.setBounds(900, 470,115,50);
		this.add(r30);
		
		play=new JButton("GO TO WAR!");
		play.setBounds(550, 600, 100, 50);
		play.addActionListener(this);
		this.add(play);
		
		this.validate();
		this.repaint();
		
	}
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==info) {
			main.ChampionsToInfo();
		}
			ArrayList<String> a=new ArrayList<String>();
			int i=0;
			if(r1.isSelected()) {
				a.add(r1.getText());
				i+=1;
			}
			if(r2.isSelected()) {
				a.add(r2.getText());
				i+=1;
			}
			if(r3.isSelected()) {
				i+=1;
				a.add(r3.getText());
			}
				
			if(r4.isSelected()) {
				i+=1;
				a.add(r4.getText());
			}
			if(r5.isSelected()) {
				i+=1;
				a.add(r5.getText());
			}
			if(r6.isSelected()) {
				i+=1;
				a.add(r6.getText());
			}
			if(r7.isSelected()) {
				i+=1;
				a.add(r7.getText());
			}
			if(r8.isSelected()) {
				i+=1;
				a.add(r8.getText());
			}
			if(r9.isSelected()) {
				i+=1;
				a.add(r9.getText());
			}
			if(r10.isSelected()) {
				i+=1;
				a.add(r10.getText());
			}
			if(r11.isSelected()) {
				i+=1;
				a.add(r11.getText());
			}
			if(r12.isSelected()) {
				i+=1;
				a.add(r12.getText());
			}
			if(r13.isSelected()) {
				i+=1;
				a.add(r13.getText());
			}
			if(r14.isSelected()) {
				i+=1;
				a.add(r14.getText());
			}
			if(r15.isSelected()) {
				i+=1;
				a.add(r15.getText());
			}
			
			ArrayList<String> b= new ArrayList<String>();
			int j=0;
			if(r16.isSelected()) {
				j+=1;
				b.add(r16.getText());
			}
			if(r17.isSelected()) {
				j+=1;
				b.add(r17.getText());
			}
			if(r18.isSelected()){
				j+=1;
				b.add(r18.getText());
			}
			if(r19.isSelected()) {
				j+=1;
				b.add(r19.getText());
			}
			if(r20.isSelected()) {
				j+=1;
				b.add(r20.getText());
			}
			if(r21.isSelected()) {
				j+=1;
				b.add(r21.getText());
			}
			if(r22.isSelected()) {
				j+=1;
				b.add(r22.getText());
			}
			if(r23.isSelected()) {
				j+=1;
				b.add(r23.getText());
			}
			if(r24.isSelected()) {
				j+=1;
				b.add(r24.getText());
			}
			if(r25.isSelected()) {
				j+=1;
				b.add(r25.getText());
			}
			if(r26.isSelected()) {
				j+=1;
				b.add(r26.getText());
			}
			if(r27.isSelected()) {
				j+=1;
				b.add(r27.getText());
			}
			if(r28.isSelected()) {
				j+=1;
				b.add(r28.getText());
			}
			if(r29.isSelected()) {
				j+=1;
				b.add(r29.getText());
			}
			if(r30.isSelected()) {
				j+=1;
				b.add(r30.getText());
			}
			 
			if(e.getSource()== play) {
				
				if(i!=3) {
					JOptionPane.showMessageDialog(this,main.getPlayerOnesName() + " must chose 3 champions","Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				else {
					if(j!=3) {
						JOptionPane.showMessageDialog(this,main.getPlayerTwosName() + " must chose 3 champions","Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					else {
						for(int k=0;k<a.size();k++) {
							for(int w=0;w<b.size();w++) {
								if(a.get(k).equalsIgnoreCase(b.get(w))) {
									JOptionPane.showMessageDialog(this, " Two different players can't select the same champion","Error", JOptionPane.ERROR_MESSAGE);
									return;
								}
							}
							
			}
						if(c1.getSelectedIndex()==0 || c2.getSelectedIndex()==0) {
							JOptionPane.showMessageDialog(this, "Please select your leader","Error", JOptionPane.ERROR_MESSAGE);
							return;
						}
						else {
						boolean flag=false;
						for(int q=0;q<a.size();q++) {
							if(a.get(q).equalsIgnoreCase(Game.getAvailableChampions().get(c1.getSelectedIndex()-1).getName())) {
								flag=true;
								break;
							}
						}
						if(!flag) {
							JOptionPane.showMessageDialog(this, "Your chosen leader must be one of your selected Champions","Error", JOptionPane.ERROR_MESSAGE);
							return;
						}
			
						boolean flag2=false;
						for(int q=0;q<b.size();q++) {
							if(b.get(q).equalsIgnoreCase(Game.getAvailableChampions().get(c2.getSelectedIndex()-1).getName())) {
								flag2=true;
								break;
							}
						}
						if(!flag2) {
							JOptionPane.showMessageDialog(this, "Your chosen leader must be one of your selected Champions","Error", JOptionPane.ERROR_MESSAGE);
							return;
						}
						}
					}
				}
				main.ChampionsToGame(a,b,c1.getSelectedIndex(),c2.getSelectedIndex());
			
		}
			
			
	}
	public String[] AvailableChampionsByNames() {
		String[] a= new String[Game.getAvailableChampions().size()+1];
		a[0]= "Please Select Your Leader";
		for(int i=0;i<Game.getAvailableChampions().size();i++) {
			a[i+1]=Game.getAvailableChampions().get(i).getName();
					
		}
		return a;
	}
	
}














