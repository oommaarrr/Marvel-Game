import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import engine.Game;
import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;

public class Play extends JPanel implements ActionListener {
	private Marvel main;
	
	private JPanel panel1;
	private JButton[][] cells;
	
	private JButton useleader;
	private JButton endt;
	
	private JButton movedown;
	private JButton moveup;
	private JButton moveleft;
	private JButton moveright;
	private JTextArea text;
	private JScrollPane scroll;
	private JButton rem11;
	private JButton rem12;
	private JButton rem13;
	private JButton rem21;
	private JButton rem22;
	private JButton rem23;
	private JLabel player1;
	private JLabel player2;
	private JLabel lead1;
	private JLabel lead2;
	
	private JButton turnor;
	
	private JButton attackdown;
	private JButton attackup;
	private JButton attackleft;
	private JButton attackright;	
	private JRadioButton c1;
	private JRadioButton c2;
	private JRadioButton c3;
	private JButton castsingle;
	private JComboBox castdirect;
	private JButton cast;
	
	private int x=0;
	private int y=0;

	public Play(Marvel main) {
		this.main=main;
		this.setLayout(null);
		main.setSize(1200,700);
		main.setResizable(false);
		
		attackup=new JButton("Attack");
		attackup.setBounds(53, 30, 80, 30);
		this.add(attackup);
		attackup.addActionListener(this);
		
		attackleft=new JButton("Attack");
		attackleft.setBounds(10, 55, 80, 30);
		this.add(attackleft);
		attackleft.addActionListener(this);
		
		attackright=new JButton("Attack");
		attackright.setBounds(100, 55, 80, 30);
		this.add(attackright);
		attackright.addActionListener(this);
		
		attackdown=new JButton("Attack");
		attackdown.setBounds(53, 80, 80, 30);
		this.add(attackdown);
		attackdown.addActionListener(this);
		
		c1 = new JRadioButton(main.getGame().getCurrentChampion().getAbilities().get(0).getName());
		c1.setBounds(10, 130, 180,40);
		c1.setSelected(true);
		this.add(c1);
		
		c2 = new JRadioButton(main.getGame().getCurrentChampion().getAbilities().get(1).getName());
		c2.setBounds(10, 160, 180,40);
		this.add(c2);
		
		c3 = new JRadioButton(main.getGame().getCurrentChampion().getAbilities().get(2).getName());
		c3.setBounds(10, 190, 180,40);
		this.add(c3);
		
		ButtonGroup b=new ButtonGroup();
		b.add(c1);
		b.add(c2);
		b.add(c3);
		
		String[] dir= {"Cast Directional Ability","UP","DOWN","LEFT","RIGHT"};
		castdirect= new JComboBox(dir) ;
		castdirect.setFont(new Font("Serif",Font.PLAIN,12));
		castdirect.setBounds(10, 240, 180, 40);
		this.add(castdirect);
		castdirect.addActionListener(this);
		
		castsingle= new JButton("Cast Single Target Ability");
		castsingle.setBounds(10, 270, 180, 40);
		this.add(castsingle);
		castsingle.addActionListener(this);
		
		cast= new JButton("Cast Ability");
		cast.setBounds(10, 310, 180, 40);
		this.add(cast);
		cast.addActionListener(this);
		
		useleader= new JButton("Use Leader Ability");
		useleader.setBounds(10, 400, 180, 40);
		this.add(useleader);
		useleader.addActionListener(this);
		
		endt= new JButton("End Turn");
		endt.setBounds(10, 460, 180, 40);
		this.add(endt);
		endt.addActionListener(this);
		
		panel1= new JPanel();
		panel1.setLayout(new GridLayout(5,5));
		panel1.setBounds(200, 0, 800, 500);
		this.add(panel1);
		
		cells = new JButton[5][5];
		for(int i=0;i<cells.length;i++) {
			for(int j=0;j<cells.length;j++) {
				cells[i][j] = new JButton();
				cells[i][j].addActionListener(this);
				panel1.add(cells[i][j]);
			}
		}
		col();
		moveup=new JButton("Move");
		moveup.setBounds(1053, 30, 80, 30);
		this.add(moveup);
		moveup.addActionListener(this);
		
		moveleft=new JButton("Move");
		moveleft.setBounds(1010, 55, 80, 30);
		this.add(moveleft);
		moveleft.addActionListener(this);
		
		moveright=new JButton("Move");
		moveright.setBounds(1100, 55, 80, 30);
		this.add(moveright);
		moveright.addActionListener(this);
		
		movedown=new JButton("Move");
		movedown.setBounds(1053, 80, 80, 30);
		this.add(movedown);
		movedown.addActionListener(this);
		
		text = new JTextArea();
		text.setEditable(false);
		scroll = new JScrollPane(text);
		scroll.setBounds(1010, 120, 180, 260);
		this.add(scroll);
		CurrInfo();
		
		player1=new JLabel(main.getGame().getFirstPlayer().getName());
		player1.setBounds(250, 510, 50, 20);
		this.add(player1);
		
		player2=new JLabel(main.getGame().getSecondPlayer().getName());
		player2.setBounds(390, 510, 50, 20);
		this.add(player2);
		
		lead1= new JLabel("Leader Ability NOT Used");
		lead1.setBounds(225,525,150,20);
		lead1.setFont(new Font("Serif",Font.PLAIN,10));
		this.add(lead1);
		
		lead2= new JLabel("Leader Ability NOT Used");
		lead2.setBounds(365,525,150,20);
		lead2.setFont(new Font("Serif",Font.PLAIN,10));
		this.add(lead2);
		
		rem11=new JButton(main.getGame().getFirstPlayer().getTeam().get(0).getName());
		rem11.setBounds(210, 540, 140,30);
		rem11.addActionListener(this);
		this.add(rem11);
		
		rem12=new JButton(main.getGame().getFirstPlayer().getTeam().get(1).getName());
		rem12.setBounds(210, 565, 140,30);
		rem12.addActionListener(this);
		this.add(rem12);
		
		rem13=new JButton(main.getGame().getFirstPlayer().getTeam().get(2).getName());
		rem13.setBounds(210, 590, 140,30);
		rem13.addActionListener(this);
		this.add(rem13);
		
		if(main.getGame().getFirstPlayer().getTeam().get(0).getName().equalsIgnoreCase(main.getGame().getFirstPlayer().getLeader().getName()))
			rem11.setBackground(Color.cyan);
		if(main.getGame().getFirstPlayer().getTeam().get(1).getName().equalsIgnoreCase(main.getGame().getFirstPlayer().getLeader().getName()))
			rem12.setBackground(Color.cyan);
		if(main.getGame().getFirstPlayer().getTeam().get(2).getName().equalsIgnoreCase(main.getGame().getFirstPlayer().getLeader().getName()))
			rem13.setBackground(Color.cyan);
			
		rem21=new JButton(main.getGame().getSecondPlayer().getTeam().get(0).getName());
		rem21.setBounds(350, 540, 140,30);
		rem21.addActionListener(this);
		this.add(rem21);
		
		rem22=new JButton(main.getGame().getSecondPlayer().getTeam().get(1).getName());
		rem22.setBounds(350, 565, 140,30);
		rem22.addActionListener(this);
		this.add(rem22);
		
		rem23=new JButton(main.getGame().getSecondPlayer().getTeam().get(2).getName());
		rem23.setBounds(350, 590, 140,30);
		rem23.addActionListener(this);
		this.add(rem23);
		
		if(main.getGame().getSecondPlayer().getTeam().get(0).getName().equalsIgnoreCase(main.getGame().getSecondPlayer().getLeader().getName()))
			rem21.setBackground(Color.cyan);
		if(main.getGame().getSecondPlayer().getTeam().get(1).getName().equalsIgnoreCase(main.getGame().getSecondPlayer().getLeader().getName()))
			rem22.setBackground(Color.cyan);
		if(main.getGame().getSecondPlayer().getTeam().get(2).getName().equalsIgnoreCase(main.getGame().getSecondPlayer().getLeader().getName()))
			rem23.setBackground(Color.cyan);
		
		turnor= new JButton("Trun Order");
		turnor.setBounds(1010, 400, 180, 40);
		turnor.addActionListener(this);
		this.add(turnor);
		
	/*	ab= new JButton("Ability and Effect INFO");
		ab.setBounds(1010, 460, 180, 40);
		ab.addActionListener(this);
		this.add(ab);*/
		
		/*try {
		    UIManager.setLookAndFeel( UIManager.getCrossPlatformLookAndFeelClassName() );
		 } catch (Exception e) {
		            e.printStackTrace();
		 }*/
		
	}
	public void actionPerformed(ActionEvent e) {
		for(int i=0;i<cells.length;i++) {
			for(int j=0;j<cells.length;j++) {
				if(e.getSource()==cells[i][j]) {
						x=i;
						y=j;
					}
				}
			}
		
		for(int i=4;i>=0;i--) {
			for(int j=4;j>=0;j--) {
				if(e.getSource()==cells[i][j]) {
					x=i;
					y=j;
				}
					
			}
		}
		
		if(e.getSource()==rem11) {
			int i= getChampIndex(rem11.getText());
			String s= ChampInfo(i);
			JOptionPane.showMessageDialog(this,s,"Champion's Information", JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==rem12) {
			int i= getChampIndex(rem12.getText());
			String s= ChampInfo(i);
			JOptionPane.showMessageDialog(this,s,"Champion's Information", JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==rem13) {
			int i= getChampIndex(rem13.getText());
			String s= ChampInfo(i);
			JOptionPane.showMessageDialog(this,s,"Champion's Information", JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==rem21) {
			int i= getChampIndex(rem21.getText());
			String s= ChampInfo(i);
			JOptionPane.showMessageDialog(this,s,"Champion's Information", JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==rem22) {
			int i= getChampIndex(rem22.getText());
			String s= ChampInfo(i);
			JOptionPane.showMessageDialog(this,s,"Champion's Information", JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==rem23) {
			int i= getChampIndex(rem23.getText());
			String s= ChampInfo(i);
			JOptionPane.showMessageDialog(this,s,"Champion's Information", JOptionPane.INFORMATION_MESSAGE);
		}
		
		if(e.getSource()==turnor) {
			String s="";
			PriorityQueue p=new PriorityQueue(main.getGame().getTurnOrder().size());
			while(!main.getGame().getTurnOrder().isEmpty()) {
				Champion c= (Champion) main.getGame().getTurnOrder().peekMin();
				s+=c.getName()+ "\n";
				p.insert(main.getGame().getTurnOrder().remove());
				
			}
			while(!p.isEmpty()) {
			main.getGame().getTurnOrder().insert(p.remove());
			}
			JOptionPane.showMessageDialog(this,s,"Champion's Turn Order", JOptionPane.INFORMATION_MESSAGE);
		}
		
		if(e.getSource()==useleader) {
			try {
				main.getGame().useLeaderAbility();
			} catch (LeaderNotCurrentException | LeaderAbilityAlreadyUsedException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
			if(main.getGame().isFirstLeaderAbilityUsed()) {
				lead1.setText("Leader Ablity Used");
			}
			if(main.getGame().isSecondLeaderAbilityUsed()) {
				lead2.setText("Leader Ablity Used");
			}
		}
		
		if(e.getSource()==endt) {
			main.getGame().endTurn();
			c1.setText(main.getGame().getCurrentChampion().getAbilities().get(0).getName());
			c2.setText(main.getGame().getCurrentChampion().getAbilities().get(1).getName());
			c3.setText(main.getGame().getCurrentChampion().getAbilities().get(2).getName());
			CurrInfo();
			col();
			
			}
		
		if(e.getSource()==moveup) {
			try {
				main.getGame().move(Direction.DOWN);
			} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		
		if(e.getSource()==movedown) {
			try {
				main.getGame().move(Direction.UP);
			} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		
		if(e.getSource()==moveleft) {
			try {
				main.getGame().move(Direction.LEFT);
			} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		
		if(e.getSource()==moveright) {
			try {
				main.getGame().move(Direction.RIGHT);
			} catch (NotEnoughResourcesException | UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		} 
		
		if(e.getSource()==attackup) {
			try {
				main.getGame().attack(Direction.DOWN);
			} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		
		if(e.getSource()==attackdown) {
			try {
				main.getGame().attack(Direction.UP);
			} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		
		if(e.getSource()==attackleft) {
			try {
				main.getGame().attack(Direction.LEFT);
			} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		
		if(e.getSource()==attackright) {
			try {
				main.getGame().attack(Direction.RIGHT);
			} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		boolean r11=false;
		for(int i=0;i<main.getGame().getFirstPlayer().getTeam().size();i++) {
			if(rem11.getText().equalsIgnoreCase(main.getGame().getFirstPlayer().getTeam().get(i).getName())) {
				r11=true;
				break;
			}
		}
		if(!r11) {
			rem11.setVisible(false);
		}
		
		
		boolean r12=false;
		for(int i=0;i<main.getGame().getFirstPlayer().getTeam().size();i++) {
			if(rem12.getText().equalsIgnoreCase(main.getGame().getFirstPlayer().getTeam().get(i).getName())) {
				r12=true;
				break;
			}
		}
		if(!r12) {
			rem12.setVisible(false);
		}
		
		
		boolean r13=false;
		for(int i=0;i<main.getGame().getFirstPlayer().getTeam().size();i++) {
			if(rem13.getText().equalsIgnoreCase(main.getGame().getFirstPlayer().getTeam().get(i).getName())) {
				r13=true;
				break;
			}
		}
		if(!r13) {
			rem13.setVisible(false);
		}
		
		
		boolean r21=false;
		for(int i=0;i<main.getGame().getSecondPlayer().getTeam().size();i++) {
			if(rem21.getText().equalsIgnoreCase(main.getGame().getSecondPlayer().getTeam().get(i).getName())) {
				r21=true;
				break;
			}
		}
		if(!r21) {
			rem21.setVisible(false);
		}
		
		
		boolean r22=false;
		for(int i=0;i<main.getGame().getSecondPlayer().getTeam().size();i++) {
			if(rem22.getText().equalsIgnoreCase(main.getGame().getSecondPlayer().getTeam().get(i).getName())) {
				r22=true;
				break;
			}
		}
		if(!r22) {
			rem22.setVisible(false);
		}
		
		
		boolean r23=false;
		for(int i=0;i<main.getGame().getSecondPlayer().getTeam().size();i++) {
			if(rem23.getText().equalsIgnoreCase(main.getGame().getSecondPlayer().getTeam().get(i).getName())) {
				r23=true;
				break;
			}
		}
		if(!r23) {
			rem23.setVisible(false);
		}
		
		if(e.getSource()==castsingle) {
			String s="";
			if(c1.isSelected())
				s=c1.getText();
			if(c2.isSelected())
				s=c2.getText();
			if(c3.isSelected())
				s=c3.getText();
			Ability a=findAbilityByName(s);
			try {
				main.getGame().castAbility(a, x, y);
			} catch (NotEnoughResourcesException | AbilityUseException | InvalidTargetException
					| CloneNotSupportedException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			CurrInfo();
			col();
		}
		if(e.getSource()==cast) {
			String s="";
			if(c1.isSelected())
				s=c1.getText();
			if(c2.isSelected())
				s=c2.getText();
			if(c3.isSelected())
				s=c3.getText();
			Ability a=findAbilityByName(s);
			if(castdirect.getSelectedIndex()==0) {
				try {
					main.getGame().castAbility(a);
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
				}
				CurrInfo();
				col();
			}
			else {
				Direction d= Direction.UP	;
				if(castdirect.getSelectedIndex()==1) {
					d=Direction.UP;
				}
				if(castdirect.getSelectedIndex()==2) {
					d=Direction.DOWN;
				}
				if(castdirect.getSelectedIndex()==3) {
					d=Direction.LEFT;
				}
				if(castdirect.getSelectedIndex()==4) {
					d=Direction.RIGHT;
				}
				
					try {
						main.getGame().castAbility(a,d);
					} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(this,e1.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
					}
					CurrInfo();
					col();
			}
		}
		if(main.getGame().checkGameOver()!= null) {
			String s= "Winner is: "+ main.getGame().checkGameOver().getName();
			JOptionPane.showMessageDialog(this,s,"Game Over", JOptionPane.INFORMATION_MESSAGE);
			main.dispose();
		}
		}
	public int getChampIndex(String c) {
		for(int i=0;i<Game.getAvailableChampions().size();i++) {
			if(Game.getAvailableChampions().get(i).getName().equalsIgnoreCase(c))
				return i;
		}
		return 0;
	}
	public String ChampInfo(int i) {
		String s="";
		Champion cc= Game.getAvailableChampions().get(i);
		Champion c=null;
		if(main.getGame().getFirstPlayer().getTeam().contains(cc)) {
			for(int w=0;w<main.getGame().getFirstPlayer().getTeam().size();w++) {
				if(main.getGame().getFirstPlayer().getTeam().get(w).getName().equals(cc.getName()))
					c=main.getGame().getFirstPlayer().getTeam().get(w);
			}
		}
		else {
			for(int w=0;w<main.getGame().getSecondPlayer().getTeam().size();w++) {
				if(main.getGame().getSecondPlayer().getTeam().get(w).getName().equals(cc.getName()))
					c=main.getGame().getSecondPlayer().getTeam().get(w);
			}
		}
		s= "Champion Type: ";
		if(c instanceof Hero)
			s+="Hero" +"\n";
		if(c instanceof Villain)
			s+="Villain" +"\n";
		if(c instanceof AntiHero)
			s+="AntiHero" +"\n";
		s+= "Champion's name: " + c.getName()+ "\n"+ "Champion's Max HP: "+ c.getMaxHP()+"\n"+"Champion's Current HP: "+ c.getCurrentHP()+"\n"+
			"Champion's Mana: "+ c.getMana() +"\n"+ "Champion's Maximum Action Points per turn: "+ c.getMaxActionPointsPerTurn()+
			"\n" + "Champion's Speed: " + c.getSpeed()+"\n"+"Champion's Attack Damage: " + c.getAttackDamage()+
			"\n" + "Champion's Attack Range: " + c.getAttackRange()+"\n";
		for(Ability a: c.getAbilities()) {
			s+=AbilityInfo(s,a.getName());
		}
		for(Effect e : c.getAppliedEffects()) {
			s+="Applied Effect: " + e.getName()+"\n"+"    ~ Effect's Duration: "+ e.getDuration()+"\n";
		}
		return s;
	}
	public String AbilityInfo(String s,String a) {
		s="";
		for(Ability e: Game.getAvailableAbilities()) {		
			if(e.getName().equalsIgnoreCase(a)) {
				s+="Ability's Name: " + e.getName()+"\n";
				if(e instanceof DamagingAbility)
					s+= "    ~ Ability Type: Damaging Ability"+"\n";
				if(e instanceof CrowdControlAbility)
					s+= "    ~ Ability Type: Crowd Control Ability"+"\n";
				if(e instanceof HealingAbility)
					s+= "    ~ Ability Type: Healing Ability"+"\n";
					s+= "    ~ Ability's Mana Cost"+ e.getManaCost()+"\n"+
							"    ~ Ability's Cast Range: "+ e.getCastRange()+"\n"+ 
							"    ~ Ability's Base Cooldown: "+e.getBaseCooldown()+"\n"+
							"    ~ Ability's Area of Effect: "+ e.getCastArea()+"\n"+
							"    ~ Ability's Required Action Points: "+ e.getRequiredActionPoints()+"\n";
				if(e instanceof DamagingAbility)
					s+="    ~ Ability's Damage Amount: "+ ((DamagingAbility) e).getDamageAmount();
				if(e instanceof HealingAbility)
					s+="    ~ Ability's Healing Amount: "+ ((HealingAbility) e).getHealAmount();
				if(e instanceof CrowdControlAbility)
					s+="    ~ Ability's Effect Name: "+((CrowdControlAbility) e).getEffect().getName()+"\n"+
							"    ~ Ability's Effect Duration: " +((CrowdControlAbility) e).getEffect().getDuration();
			} 
		}
		s+="\n";
		return s;
	}
	public void CurrInfo() {
		String s="";
		Champion c= main.getGame().getCurrentChampion();
		s= "Champion Type: ";
		if(c instanceof Hero)
			s+="Hero" +"\n";
		if(c instanceof Villain)
			s+="Villain" +"\n";
		if(c instanceof AntiHero)
			s+="AntiHero" +"\n";
		s+= "Champion's name: " + c.getName()+ "\n"+ "Champion's Max HP: "+ c.getMaxHP()+"\n"+
			"Champion's Mana: "+ c.getMana() +"\n"+ "Champion's Maximum Action Points per turn: "+ c.getMaxActionPointsPerTurn()+
			"\n" +"Champion's current Action Points "+ c.getCurrentActionPoints()+"\n"+"Champion's Speed: " + c.getSpeed()+"\n"+"Champion's Attack Damage: " + c.getAttackDamage()+
			"\n" + "Champion's Attack Range: " + c.getAttackRange()+"\n";
		for(Ability a: c.getAbilities()) {
			s+=AbilityInfo(s,a.getName());
		}
		for(Effect e : c.getAppliedEffects()) {
			s+="Applied Effect: " + e.getName()+"\n"+"    ~ Effect's Duration: "+ e.getDuration()+"\n";
		}
		text.setText(s);
		text.setFont(new Font("Serif",Font.PLAIN,7));	
		}
	public void col() {
		for(int i=0;i<=4;i++) {
			for(int j=0;j<=4;j++) {
				cells[i][j].setOpaque(true);
				if(main.getGame().getBoard()[i][j] instanceof Champion) {
					if((Champion) main.getGame().getBoard()[i][j] == main.getGame().getCurrentChampion()) {
						cells[i][j].setBackground(Color.BLUE);
						cells[i][j].setText(((Champion) main.getGame().getBoard()[i][j]).getName()+"\n"+"Current HP: "+((Champion) main.getGame().getBoard()[i][j]).getCurrentHP());
						cells[i][j].setFont(new Font("Serif",Font.PLAIN,7));
					}
					else {
						if(main.getGame().getFirstPlayer().getTeam().contains((Champion) main.getGame().getBoard()[i][j])) {
							cells[i][j].setBackground(Color.PINK);
							cells[i][j].setText(((Champion) main.getGame().getBoard()[i][j]).getName()+"\n"+"Current HP: "+((Champion) main.getGame().getBoard()[i][j]).getCurrentHP());
							cells[i][j].setFont(new Font("Serif",Font.PLAIN,7));
						}
						else {
							cells[i][j].setBackground(Color.green);
							cells[i][j].setText(((Champion) main.getGame().getBoard()[i][j]).getName()+"\n"+"Current HP: "+((Champion) main.getGame().getBoard()[i][j]).getCurrentHP());
							cells[i][j].setFont(new Font("Serif",Font.PLAIN,7));
						}
					}
					
				}
				else {
					if(main.getGame().getBoard()[i][j] instanceof Cover) {
						cells[i][j].setBackground(Color.LIGHT_GRAY);
						cells[i][j].setText("Cover"+"\n" +"Current HP: "+((Cover) main.getGame().getBoard()[i][j]).getCurrentHP());
						cells[i][j].setFont(new Font("Serif",Font.PLAIN,7));
					}
					else {
						cells[i][j].setBackground(Color.magenta);
						cells[i][j].setText("");
					}
				}
			}
		}
	}
	private static Ability findAbilityByName(String name) {
		for (Ability a : Game.getAvailableAbilities()) {
			if (a.getName().equals(name))
				return a;
		}
		return null;
	}
}
