import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class players extends JPanel implements ActionListener{
	private Marvel main;
	private JLabel player1;
	private JLabel player2;
	private JTextField field1;
	private JTextField field2;
	private JButton start;
	
	 public players (Marvel main)  {
		 this.main=main;
		 this.setLayout(null);
		 main.setSize(1200,740);
		 
		 player1 = new JLabel("player 1 Nickname");
		 player1.setBounds(20, 60, 120, 100);
		 this.add(player1);
		 
		 player2 = new JLabel("player 2 Nickname");
		 player2.setBounds(20, 130, 120, 100);
		 this.add(player2);
		  
		 field1= new JTextField("Player 1");
		 field1.setBounds(150, 100, 150, 25);
		 this.add(field1);
		 
		 field2= new JTextField("Player 2");
		 field2.setBounds(150, 170, 150, 25);
		 this.add(field2);
		 
		 start=new JButton("Choose Champions");
		 start.setBounds(300,300,300,40);
		 start.addActionListener(this);
		 this.add(start);
		
		 main.setBackground(Color.RED);
		 this.validate();
		 this.repaint();
		 
	 }

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == start) {
			if(field1.getText().equals("")) {				
				JOptionPane.showMessageDialog(this,"Please enter player one's nickname","Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(field2.getText().equals("")) {
					JOptionPane.showMessageDialog(this,"Please enter player two's nickname","Error", JOptionPane.ERROR_MESSAGE);
				}
				else {
					main.switchToChampions(field1.getText(),field2.getText());
				}
		}
		
	}

}
