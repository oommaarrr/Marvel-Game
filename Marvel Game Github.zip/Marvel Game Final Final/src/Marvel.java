import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import engine.Game;
import engine.Player;
import model.world.Champion;


public class Marvel extends JFrame implements ActionListener{
	private Game game;
	private String name1;
	private String name2;
	private players players;
	private Champions champions;
	private Info info;
	private Play play;
	public Marvel ()  { 
		players= new players(this);
		this.getContentPane().add(players);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		 this.validate();
		 this.setTitle("Marvel Ultimate War");
		 this.repaint();
		 this.setVisible(true);
		 
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
		
	public void switchToChampions(String name1,String name2)  {
		this.name1=name1;
		this.name2=name2;
		
		try {
			Game.loadAbilities("Abilities.csv");
			Game.loadChampions("Champions.csv");
			this.remove(players);
			champions= new Champions(this);
			this.getContentPane().add(champions);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		this.validate();
		this.repaint();
		
	}
	public static void main (String[] args) throws IOException {
		Marvel j=new Marvel();
		
	}
	public String getPlayerOnesName() {
		return name1;
	}
	public String getPlayerTwosName() {
		return name2;
	}	
	
	public void ChampionsToInfo() {
		try {
		this.remove(champions);
		 info= new Info(this);
		this.getContentPane().add(info);
		} catch(Exception e) {
			e.printStackTrace();
		}
		this.validate();
		this.repaint();
	}
	public void InfoToChampions() {
		try{
		this.remove(info);
		this.getContentPane().add(champions);
		} catch(Exception e) {
			e.printStackTrace();
		}
		this.validate();
		this.repaint();
	}
	public Game getGame() {
		return game;
	}
	public void ChampionsToGame(ArrayList<String> a,ArrayList<String> b,int l1,int l2) {
		Player h=new Player(name1);
		Player s=new Player(name2);
		for(String f : a) {
			for(Champion c : Game.getAvailableChampions()) {
				if(c.getName().equalsIgnoreCase(f)) {
					h.getTeam().add(c);
					break;
				}
			}
		}
		for(String f : b) {
			for(Champion c : Game.getAvailableChampions()) {
				if(c.getName().equalsIgnoreCase(f)) {
					s.getTeam().add(c);
					break;
				}
			}
		}
		--l1;
		--l2;
		h.setLeader(Game.getAvailableChampions().get(l1));
		s.setLeader(Game.getAvailableChampions().get(l2));
		game = new Game(h,s);
		this.remove(champions);
		play = new Play(this);
		this.getContentPane().add(play);
		this.validate();
		this.repaint();
	}
}
