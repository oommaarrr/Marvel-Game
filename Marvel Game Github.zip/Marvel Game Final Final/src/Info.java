import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import engine.Game;
import model.abilities.Ability;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Hero;
import model.world.Villain;

public class Info extends JPanel implements ActionListener {
	private Marvel main;
	private JButton back;
	private JButton b1;
	private JButton b2;
	private JButton b3;
	private JButton b4;
	private JButton b5;
	private JButton b6;
	private JButton b7;
	private JButton b8;
	private JButton b9;
	private JButton b10;
	private JButton b11;
	private JButton b12;
	private JButton b13;
	private JButton b14;
	private JButton b15;
	private JLabel chose;
	private JTextArea text;
	private JScrollPane scroll;

public Info(Marvel main) {
	this.main=main;
	this.setLayout(null);

	chose=new JLabel("Please select a champion to know all their information");
	chose.setBounds(20, 10, 500, 20);
	this.add(chose);
	
	back=new JButton("Back");
	back.setBounds(20, 600, 200, 30);
	back.addActionListener(this);
	this.add(back);
	
	text=new JTextArea();
	text.setEditable(false);
	scroll = new JScrollPane(text);
	scroll.setBounds(200,50,500,500);
	this.add(scroll);
	
	b1= new JButton(Game.getAvailableChampions().get(0).getName());
	b1.setBounds(20, 50,150,30);
	b1.addActionListener(this);
	this.add(b1);
	
	b2= new JButton(Game.getAvailableChampions().get(1).getName());
	b2.setBounds(20, 80,150,30);
	b2.addActionListener(this);
	this.add(b2);
	
	b3= new JButton(Game.getAvailableChampions().get(2).getName());
	b3.setBounds(20, 110,150,30);
	b3.addActionListener(this);
	this.add(b3);
	
	b4= new JButton(Game.getAvailableChampions().get(3).getName());
	b4.setBounds(20, 140,150,30);
	b4.addActionListener(this);
	this.add(b4);
	
	b5= new JButton(Game.getAvailableChampions().get(4).getName());
	b5.setBounds(20, 170,150,30);
	b5.addActionListener(this);
	this.add(b5);
	
	b6= new JButton(Game.getAvailableChampions().get(5).getName());
	b6.setBounds(20, 200,150,30);
	b6.addActionListener(this);
	this.add(b6);
	
	b7= new JButton(Game.getAvailableChampions().get(6).getName());
	b7.setBounds(20, 230,150,30);
	b7.addActionListener(this);
	this.add(b7);
	
	b8= new JButton(Game.getAvailableChampions().get(7).getName());
	b8.setBounds(20, 260,150,30);
	b8.addActionListener(this);
	this.add(b8);
	
	b9= new JButton(Game.getAvailableChampions().get(8).getName());
	b9.setBounds(20, 290,150,30);
	b9.addActionListener(this);
	this.add(b9);
	
	b10= new JButton(Game.getAvailableChampions().get(9).getName());
	b10.setBounds(20, 320,150,30);
	b10.addActionListener(this);
	this.add(b10);
	
	b11= new JButton(Game.getAvailableChampions().get(10).getName());
	b11.setBounds(20, 350,150,30);
	b11.addActionListener(this);
	this.add(b11);
	
	b12= new JButton(Game.getAvailableChampions().get(11).getName());
	b12.setBounds(20, 380,150,30);
	b12.addActionListener(this);
	this.add(b12);
	
	b13= new JButton(Game.getAvailableChampions().get(12).getName());
	b13.setBounds(20, 410,150,30);
	b13.addActionListener(this);
	this.add(b13);
	
	b14= new JButton(Game.getAvailableChampions().get(13).getName());
	b14.setBounds(20, 440,150,30);
	b14.addActionListener(this);
	this.add(b14);
	
	b15= new JButton(Game.getAvailableChampions().get(14).getName());
	b15.setBounds(20, 470,150,30);
	b15.addActionListener(this);
	this.add(b15);
	
	this.validate();
	this.repaint();
}

public void actionPerformed(ActionEvent e) {
	if(e.getSource()==back) {
		main.InfoToChampions();
	}
	if(e.getSource()==b1) {
		text.setText(ChampInfo(0));
	}
	if(e.getSource()==b2) {
		text.setText(ChampInfo(1));
	}
	if(e.getSource()==b3) {
		text.setText(ChampInfo(2));
	}
	if(e.getSource()==b4) {
		text.setText(ChampInfo(3));
	}
	if(e.getSource()==b5) {
		text.setText(ChampInfo(4));
	}
	if(e.getSource()==b6) {
		text.setText(ChampInfo(5));
	}
	if(e.getSource()==b7) {
		text.setText(ChampInfo(6));
	}
	if(e.getSource()==b8) {
		text.setText(ChampInfo(7));
	}
	if(e.getSource()==b9) {
		text.setText(ChampInfo(8));
	}
	if(e.getSource()==b10) {
		text.setText(ChampInfo(9));
	}
	if(e.getSource()==b11) {
		text.setText(ChampInfo(10));
	}
	if(e.getSource()==b12) {
		text.setText(ChampInfo(11));
	}
	if(e.getSource()==b13) {
		text.setText(ChampInfo(12));
	}
	if(e.getSource()==b14) {
		text.setText(ChampInfo(13));
	}
	if(e.getSource()==b15) {
		text.setText(ChampInfo(14));
	}
	
}
public String ChampInfo(int i) {
	String s="";
	Champion c= Game.getAvailableChampions().get(i);
	s= "Champion Type: ";
	if(c instanceof Hero)
		s+="Hero" +"\n";
	if(c instanceof Villain)
		s+="Villain" +"\n";
	if(c instanceof AntiHero)
		s+="AntiHero" +"\n";
	s+= "Champion's name: " + c.getName()+ "\n"+ "Champion's Max HP: "+ c.getMaxHP()+"\n"+
		"Champion's Mana: "+ c.getMana() +"\n"+ "Champion's Maximum Action Points per turn: "+ c.getMaxActionPointsPerTurn()+
		"\n" + "Champion's Speed: " + c.getSpeed()+"\n"+"Champion's Attack Damage: " + c.getAttackDamage()+
		"\n" + "Champion's Attack Range: " + c.getAttackRange()+"\n";
	for(Ability a: c.getAbilities()) {
		s+=AbilityInfo(s,a.getName());
	}
	//s+=a+"\n"+b+"\n"+c;
	
	return s;
}
public String AbilityInfo(String s,String a) {
	s="";
	for(Ability e: Game.getAvailableAbilities()) {		
		if(e.getName().equalsIgnoreCase(a)) {
			s+="Ability's Name: " + e.getName()+"\n";
			if(e instanceof DamagingAbility)
				s+= "    ~ Ability Type: Damaging Ability"+"\n";
			if(e instanceof CrowdControlAbility)
				s+= "    ~ Ability Type: Crowd Control Ability"+"\n";
			if(e instanceof HealingAbility)
				s+= "    ~ Ability Type: Healing Ability"+"\n";
				s+= "    ~ Ability's Mana Cost"+ e.getManaCost()+"\n"+
						"    ~ Ability's Cast Range: "+ e.getCastRange()+"\n"+ 
						"    ~ Ability's Base Cooldown: "+e.getBaseCooldown()+"\n"+
						"    ~ Ability's Area of Effect: "+ e.getCastArea()+"\n"+
						"    ~ Ability's Required Action Points: "+ e.getRequiredActionPoints()+"\n";
			if(e instanceof DamagingAbility)
				s+="    ~ Ability's Damage Amount: "+ ((DamagingAbility) e).getDamageAmount();
			if(e instanceof HealingAbility)
				s+="    ~ Ability's Healing Amount: "+ ((HealingAbility) e).getHealAmount();
			if(e instanceof CrowdControlAbility)
				s+="    ~ Ability's Effect Name: "+((CrowdControlAbility) e).getEffect().getName()+"\n"+
						"    ~ Ability's Effect Duration: " +((CrowdControlAbility) e).getEffect().getDuration();
		} 
	}
	s+="\n";
	return s;

	
}

}